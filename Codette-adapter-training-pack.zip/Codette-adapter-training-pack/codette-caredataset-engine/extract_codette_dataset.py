import json
import random
from pathlib import Path
import re
import docx

SOURCE_FOLDER = "source_material"
OUTPUT_FILE = "codette_dataset.jsonl"

SYSTEM_PROMPT = "You are Codette, a scientific reasoning AI capable of explaining complex ideas clearly."

question_templates = [
    "Explain the following concept clearly:\n\n{content}",
    "Teach a beginner about this idea:\n\n{content}",
    "Summarize the meaning of this research excerpt:\n\n{content}",
    "What does this technical concept mean:\n\n{content}",
    "Why is this idea important in AI or science:\n\n{content}"
]

def clean_text(text):

    text = re.sub(r"\s+", " ", text)
    text = text.strip()

    return text

def split_into_chunks(text, size=500):

    words = text.split()
    chunks = []

    for i in range(0, len(words), size):

        chunk = " ".join(words[i:i+size])

        if len(chunk) > 200:
            chunks.append(chunk)

    return chunks

def read_docx(file):

    doc = docx.Document(file)

    text = []

    for p in doc.paragraphs:
        text.append(p.text)

    return "\n".join(text)

def read_file(path):

    ext = path.suffix.lower()

    try:

        if ext == ".txt" or ext == ".md" or ext == ".py":

            return open(path, encoding="utf8", errors="ignore").read()

        elif ext == ".docx":

            return read_docx(path)

        elif ext == ".json":

            data = json.load(open(path))
            return json.dumps(data)

    except:
        return ""

    return ""

def build_training_example(chunk):

    question = random.choice(question_templates).format(content=chunk)

    example = {
        "messages":[
            {"role":"system","content":SYSTEM_PROMPT},
            {"role":"user","content":question},
            {"role":"assistant","content":chunk}
        ]
    }

    return example

def main():

    source = Path(SOURCE_FOLDER)

    dataset = []

    for file in source.glob("**/*"):

        text = read_file(file)

        text = clean_text(text)

        chunks = split_into_chunks(text)

        for chunk in chunks:

            dataset.append(build_training_example(chunk))

    print("Generated samples:", len(dataset))

    with open(OUTPUT_FILE,"w") as f:

        for row in dataset:
            f.write(json.dumps(row) + "\n")

    print("Dataset saved to", OUTPUT_FILE)

if __name__ == "__main__":
    main()