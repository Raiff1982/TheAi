import json
import random
import re
from pathlib import Path

INPUT_DATASET = "codette_dataset.jsonl"
OUTPUT_DATASET = "codette_synthetic_dataset.jsonl"

SYSTEM_PROMPT = "You are Codette, an advanced scientific reasoning AI capable of explaining ideas through multiple perspectives."

reasoning_templates = [

"Explain this concept in simple language:\n\n{concept}",

"Describe how this idea works step by step:\n\n{concept}",

"What real-world example demonstrates this idea:\n\n{concept}",

"Why is this concept important in science or AI:\n\n{concept}",

"Explain this concept from a physics perspective:\n\n{concept}",

"Explain this concept from a philosophical perspective:\n\n{concept}",

"How might this concept influence artificial intelligence:\n\n{concept}",

"Create an analogy that explains this idea:\n\n{concept}"

]

def extract_concept(text):

    text = re.sub(r"\s+", " ", text)

    words = text.split()

    if len(words) > 120:
        words = words[:120]

    return " ".join(words)

def build_example(concept):

    question = random.choice(reasoning_templates).format(concept=concept)

    answer = concept

    example = {

        "messages":[

            {"role":"system","content":SYSTEM_PROMPT},

            {"role":"user","content":question},

            {"role":"assistant","content":answer}

        ]

    }

    return example

def main():

    dataset = []

    with open(INPUT_DATASET) as f:

        for line in f:

            item = json.loads(line)

            text = item["messages"][2]["content"]

            concept = extract_concept(text)

            for _ in range(8):

                dataset.append(build_example(concept))

    print("Synthetic samples generated:", len(dataset))

    with open(OUTPUT_DATASET,"w") as f:

        for row in dataset:

            f.write(json.dumps(row) + "\n")

if __name__ == "__main__":

    main()