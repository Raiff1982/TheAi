import torch
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer
from transformers import TrainingArguments

MODEL_NAME="meta-llama/Llama-3.1-8B"

dataset=load_dataset("json",data_files="datasets/newton_reasoning.jsonl")

tokenizer=AutoTokenizer.from_pretrained(MODEL_NAME)

model=AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    load_in_4bit=True,
    device_map="auto"
)

lora_config=LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj","v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)

model=get_peft_model(model,lora_config)

training_args=TrainingArguments(
    output_dir="./adapter_out",
    per_device_train_batch_size=2,
    gradient_accumulation_steps=4,
    num_train_epochs=3,
    learning_rate=2e-4,
    logging_steps=10,
    save_steps=100
)

trainer=SFTTrainer(
    model=model,
    train_dataset=dataset["train"],
    dataset_text_field="instruction",
    tokenizer=tokenizer,
    args=training_args
)

trainer.train()

model.save_pretrained("codette_newton_adapter")