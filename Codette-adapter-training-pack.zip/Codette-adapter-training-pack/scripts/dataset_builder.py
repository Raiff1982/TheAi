import json

def convert_txt_to_jsonl(input_file, output_file):
    with open(input_file,"r",encoding="utf8") as f:
        lines=f.readlines()

    data=[]

    for line in lines:
        parts=line.split("||")
        if len(parts)==2:
            entry={
                "instruction":parts[0].strip(),
                "output":parts[1].strip()
            }
            data.append(entry)

    with open(output_file,"w",encoding="utf8") as f:
        for d in data:
            f.write(json.dumps(d)+"\n")