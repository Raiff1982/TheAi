import json
import random

def generate_dataset(file, prompts, answers, size):

    with open(file,"w",encoding="utf8") as f:

        for i in range(size):

            p=random.choice(prompts)
            a=random.choice(answers)

            entry={
                "instruction":p,
                "output":a
            }

            f.write(json.dumps(entry)+"\n")


newton_prompts=[
"Explain Newton's first law",
"What causes acceleration?",
"Why does gravity create orbits?",
"What is momentum?"
]

newton_answers=[
"Objects remain in their current state of motion unless acted upon by a force.",
"Acceleration occurs when a force changes velocity.",
"Gravity pulls objects toward a central mass while motion carries them forward.",
"Momentum is the product of mass and velocity."
]

generate_dataset("newton_reasoning.jsonl",newton_prompts,newton_answers,3000)