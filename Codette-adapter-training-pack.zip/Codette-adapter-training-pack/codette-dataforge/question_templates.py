templates = {

"definition":[
"What is {}?",
"Define {}.",
"Explain {}."
],

"mechanism":[
"How does {} work?",
"What mechanism drives {}?"
],

"analysis":[
"Why does {} matter?",
"What are the implications of {}?"
],

"comparison":[
"How is {} different from traditional methods?"
]

}