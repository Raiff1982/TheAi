import os
import json
import random
import re

INPUT_DIR = "source_docs"
OUTPUT_FILE = "output_datasets/codette_generated.jsonl"

QUESTION_PATTERNS = [
    "Explain the concept of {}.",
    "What is the purpose of {}?",
    "Why is {} important?",
    "How does {} work?",
    "Describe the role of {} in the system."
]

def extract_sections(text):
    sections = re.split(r'\n#+ ', text)
    return [s.strip() for s in sections if len(s.strip()) > 80]

def extract_concepts(text):

    words = re.findall(r'\b[A-Z][a-zA-Z]+\b', text)

    unique = list(set(words))

    return unique[:50]

def generate_examples(section):

    concepts = extract_concepts(section)

    examples = []

    for concept in concepts:

        q = random.choice(QUESTION_PATTERNS).format(concept)

        answer = section[:500]

        examples.append({
            "instruction": q,
            "output": answer
        })

    return examples


def build_dataset():

    dataset = []

    for file in os.listdir(INPUT_DIR):

        path = os.path.join(INPUT_DIR, file)

        if not path.endswith((".md",".txt",".py")):
            continue

        with open(path,"r",encoding="utf8") as f:
            text = f.read()

        sections = extract_sections(text)

        for sec in sections:

            dataset.extend(generate_examples(sec))

    with open(OUTPUT_FILE,"w",encoding="utf8") as f:

        for entry in dataset:

            f.write(json.dumps(entry)+"\n")

    print("Dataset created:", len(dataset),"examples")


if __name__ == "__main__":
    build_dataset()