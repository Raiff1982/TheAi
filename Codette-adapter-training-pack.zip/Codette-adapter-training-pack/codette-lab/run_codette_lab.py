import subprocess
from control_panel.dashboard import show_dashboard
from control_panel.benchmark_monitor import run_benchmarks

def run_pipeline():

    print("Generating dataset")

    subprocess.run(["python","dataset_engine/extract_codette_dataset.py"])

    print("Generating synthetic dataset")

    subprocess.run(["python","dataset_engine/synthetic_reasoning_generator.py"])

    print("Training adapters")

    subprocess.run(["python","training/train_all_adapters.py"])

    print("Running benchmarks")

    score=run_benchmarks("./codette_model")

    print("Pipeline complete")

if __name__=="__main__":

    show_dashboard()

    run_pipeline()