import json
from datetime import datetime
from pathlib import Path

LOG_FILE="logs/training_history.json"

def log_training(adapter, dataset, epochs, loss):

    entry={
        "timestamp":str(datetime.utcnow()),
        "adapter":adapter,
        "dataset":dataset,
        "epochs":epochs,
        "loss":loss
    }

    path=Path(LOG_FILE)

    if path.exists():
        history=json.load(open(LOG_FILE))
    else:
        history=[]

    history.append(entry)

    json.dump(history,open(LOG_FILE,"w"),indent=2)

    print("Training logged:",entry)