from transformers import pipeline
import json

def run_benchmarks(model_path):

    tests=json.load(open("benchmarks/reasoning_tests.json"))

    pipe=pipeline(
        "text-generation",
        model=model_path,
        max_new_tokens=200
    )

    score=0

    for t in tests:

        result=pipe(t)[0]["generated_text"]

        print("\nPROMPT:",t)
        print("RESPONSE:",result)

        if len(result)>120:
            score+=1

    print("\nBenchmark score:",score,"/",len(tests))

    return score