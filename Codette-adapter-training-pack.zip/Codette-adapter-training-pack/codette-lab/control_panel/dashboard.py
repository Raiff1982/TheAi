import json
from pathlib import Path

LOG_FILE="logs/training_history.json"

def show_dashboard():

    print("\n===== CODETTE LAB DASHBOARD =====")

    if not Path(LOG_FILE).exists():
        print("No training history yet")
        return

    history=json.load(open(LOG_FILE))

    print("\nTotal training runs:",len(history))

    latest=history[-1]

    print("\nLatest run")

    print("Adapter:",latest["adapter"])
    print("Dataset:",latest["dataset"])
    print("Epochs:",latest["epochs"])
    print("Loss:",latest["loss"])