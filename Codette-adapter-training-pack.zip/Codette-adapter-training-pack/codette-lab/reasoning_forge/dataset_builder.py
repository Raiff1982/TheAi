import json

def build_training_entry(problem,solution,improved):

    entry = {

        "messages":[

            {"role":"system","content":"You are Codette, an advanced reasoning AI."},

            {"role":"user","content":problem},

            {"role":"assistant","content":improved}

        ]

    }

    return entry


def save_entry(entry,file):

    with open(file,"a") as f:

        f.write(json.dumps(entry)+"\n")