import random

templates = [

"Explain the following scientific concept clearly:\n\n{concept}",

"Break down this idea step-by-step:\n\n{concept}",

"What real-world analogy explains this concept:\n\n{concept}",

"Why is this concept important in AI or physics:\n\n{concept}",

"Describe how this concept works mathematically:\n\n{concept}"

]

def generate_problem(concept):

    prompt=random.choice(templates).format(concept=concept)

    return prompt