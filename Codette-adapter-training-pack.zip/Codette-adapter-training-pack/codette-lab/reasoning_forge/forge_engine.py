import json
from problem_generator import generate_problem
from solver_agent import solve_problem
from critic_agent import critique_solution
from dataset_builder import build_training_entry, save_entry

INPUT_DATASET="codette_dataset.jsonl"
OUTPUT_DATASET="forge_dataset.jsonl"


def run_forge():

    with open(INPUT_DATASET) as f:

        for line in f:

            item=json.loads(line)

            concept=item["messages"][2]["content"]

            problem=generate_problem(concept)

            solution=solve_problem(concept)

            critique, improved = critique_solution(problem,solution)

            entry=build_training_entry(problem,solution,improved)

            save_entry(entry,OUTPUT_DATASET)


    print("Forge dataset generated")


if __name__=="__main__":

    run_forge()