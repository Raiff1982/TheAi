def critique_solution(problem,solution):

    feedback = """

Critique:

- Does the explanation clearly define the concept?
- Are the reasoning steps logical?
- Could the explanation include a clearer example?
- Is the explanation accessible to beginners?

Suggested improvement:
Add clearer examples and simplify technical language.
"""

    improved_solution = solution + "\n\nImproved explanation:\nA simple analogy can help clarify the idea."

    return feedback, improved_solution